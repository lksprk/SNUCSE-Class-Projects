#include "Person.h"

class Work : public Person {
public:
	Work(string &_firstName, string &_lastName, string &_phoneNumber, string &_team) : Person(_firstName, _lastName, _phoneNumber) {};
	void setTeam(string _team);
	string getTeam();
	virtual void print();

private:
	string team;
};