#include "Person.h"

class Friend : public Person {
public:
	Friend(string &_firstName, string &_lastName, string &_phoneNumber, int &_age) : Person(_firstName, _lastName, _phoneNumber) {};
	void setAge(int _age);
	int getAge();
	virtual void print();

private:
	int age;
};