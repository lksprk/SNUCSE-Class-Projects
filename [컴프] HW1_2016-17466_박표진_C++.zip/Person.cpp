#include "Person.h"

Person::Person(string &_firstName, string &_lastName, string &_phoneNumber) {
	firstName = _firstName;
	lastName = _lastName;
	phoneNumber = _phoneNumber;
}
void Person::setFirstName(string _firstName) {
	firstName = _firstName;
}
void Person::setLastName(string _lastName) {
	lastName = _lastName;
}
void Person::setPhoneNumber(string _phoneNumber) {
	phoneNumber = _phoneNumber;
}
string Person::getFirstName() {
	return firstName;
}
string Person::getLastName() {
	return lastName;
}
string Person::getPhoneNumber() {
	return phoneNumber;
}
void Person::print() {
	cout << getFirstName() + " " + getLastName() + "_" + getPhoneNumber() << endl;
}

Person::~Person()
{
	delete &firstName, &lastName, &phoneNumber;
}
