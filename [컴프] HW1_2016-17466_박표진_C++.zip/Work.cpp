#include"Person.h"
#include"Work.h"

void Work::setTeam(string _team) {
	team = _team;
}
string Work::getTeam() {
	return team;
}
void Work::print() {
	cout << getFirstName() + " " + getLastName() + "_" + getPhoneNumber() + "_" + getTeam() << endl;
}