#include"Person.h"
#include"Family.h"

void Family::setBirthday(string _birthday) {
	birthday = _birthday;
}
string Family::getBirthday() {
	return birthday;
}
int Family::dDay() {
	
	time_t now = time(NULL);
	struct tm today;
	localtime_s(&today, &now);
	
	int totalDays_till_thisMonth = today.tm_mon+1;
	int todayDate = today.tm_mday;
	switch (totalDays_till_thisMonth) {
	case 1:
		totalDays_till_thisMonth = 0;
		break;
	case 2: //Feb
		totalDays_till_thisMonth = 31; // Jan; e.g. total days from Jan 1st to Feb 10th: 31 + 10 = 41 days
		break;
	case 3: //Mar
		totalDays_till_thisMonth = (31 + 28); // Jan + Feb
		break;
	case 4:
		totalDays_till_thisMonth = (31 + 28 + 31); // Jan + Feb + Mar
		break;
	case 5:
		totalDays_till_thisMonth = (31 + 28 + 31 + 30);
		break;
	case 6:
		totalDays_till_thisMonth = (31 + 28 + 31 + 30 + 31);
		break;
	case 7:
		totalDays_till_thisMonth = (31 + 28 + 31 + 30 + 31 + 30);
		break;
	case 8:
		totalDays_till_thisMonth = (31 + 28 + 31 + 30 + 31 + 30 + 31);
		break;
	case 9:
		totalDays_till_thisMonth = (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31);
		break;
	case 10:
		totalDays_till_thisMonth = (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30);
		break;
	case 11:
		totalDays_till_thisMonth = (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31);
		break;
	case 12:
		totalDays_till_thisMonth = (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30);  //Jan + Feb + Mar + ... + Nov;
		break;
	}
	int today_int = totalDays_till_thisMonth + todayDate;

	int totalDays_till_birthdayMonth = atoi(birthday.substr(2, 2).c_str());
	int birthdayDate = atoi(birthday.substr(4, 2).c_str());
	switch (totalDays_till_birthdayMonth) {
	case 1:
		totalDays_till_birthdayMonth = 0;
		break;
	case 2: //Feb
		totalDays_till_birthdayMonth = 31; // Jan; e.g. total days from Jan 1st to Feb 10th: 31 + 10 = 41 days
		break;
	case 3: //Mar
		totalDays_till_birthdayMonth = (31 + 28); // Jan + Feb
		break;
	case 4:
		totalDays_till_birthdayMonth = (31 + 28 + 31); // Jan + Feb + Mar
		break;
	case 5:
		totalDays_till_birthdayMonth = (31 + 28 + 31 + 30);
		break;
	case 6:
		totalDays_till_birthdayMonth = (31 + 28 + 31 + 30 + 31);
		break;
	case 7:
		totalDays_till_birthdayMonth = (31 + 28 + 31 + 30 + 31 + 30);
		break;
	case 8:
		totalDays_till_birthdayMonth = (31 + 28 + 31 + 30 + 31 + 30 + 31);
		break;
	case 9:
		totalDays_till_birthdayMonth = (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31);
		break;
	case 10:
		totalDays_till_birthdayMonth = (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30);
		break;
	case 11:
		totalDays_till_birthdayMonth = (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31);
		break;
	case 12:
		totalDays_till_birthdayMonth = (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30);  //Jan + Feb + Mar + ... + Nov;
		break;
	}
	int happyBirthday_int = totalDays_till_birthdayMonth + birthdayDate;

	if (today_int > happyBirthday_int) {	//birthday has already passed this year
		return 365 - (today_int - happyBirthday_int);
	}
	else if (today_int == happyBirthday_int) {	//today is a birthday
		return 0;
	}
	else {	//birthday hasn't passed this year yet
		return happyBirthday_int - today_int;
	}
}
void Family::print() {
	cout << getFirstName() + " " + getLastName() + "_" + getPhoneNumber() + "_" + getBirthday() + "_" << dDay() << endl;
}
