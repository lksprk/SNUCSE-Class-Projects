#include "Person.h"
#include <ctime>

class Family : public Person {
public:
	Family(string &_firstName, string &_lastName, string &_phoneNumber, string &_birthday) : Person(_firstName, _lastName, _phoneNumber) {};
	void setBirthday(string _birthday);
	string getBirthday();
	int dDay();
	virtual void print();

private:
	string birthday;
};