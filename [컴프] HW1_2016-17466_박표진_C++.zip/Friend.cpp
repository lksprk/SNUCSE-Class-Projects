#include"Person.h"
#include"Friend.h"

void Friend::setAge(int _age) {
	age = _age;
}
int Friend::getAge() {
	return age;
}
void Friend::print() {
	cout << getFirstName() + " " + getLastName() + "_" + getPhoneNumber() + "_" << getAge() << endl;
}