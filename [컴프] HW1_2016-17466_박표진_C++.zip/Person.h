#ifndef PERSON_H    // include only once when called at main
#define PERSON_H
#include <iostream>
#include <String>

using namespace std;

class Person
{
public:
	Person() {};
	Person(string &_firstName, string &_lastName, string &_phoneNumber);
	void setFirstName(string firstName);
	string getFirstName();
	void setLastName(string lastName);
	string getLastName();
	void setPhoneNumber(string phoneNumber);
	string getPhoneNumber();
	virtual void print();
	~Person();

private:
	string firstName;
	string lastName;
	string phoneNumber;
};

#endif