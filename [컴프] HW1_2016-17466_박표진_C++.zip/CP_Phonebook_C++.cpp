﻿#include "Person.h"
#include "Work.h"
#include "Family.h"
#include "Friend.h"
#include <vector>
#include <iostream>
#include <regex>
using namespace std;

string a = "Phone Book";
string b = "1. Add Person";
string c = "2. Remove Person";
string d = "3. Print phone book";
string e = "Select Type";
string f = "1. Person";
string g = "2. Work";
string h = "3. Family";
string i = "4. Friend";

vector<Person*> phoneBook;

int main() {
	while (true) {
		cout << "CP-2016-17466> ";

		string selectMenu;
		getline(cin, selectMenu);

		if (!selectMenu.compare("exit")) {
			exit(0);
		} // when input exit

		if (!selectMenu.length()) {
			cout << a << "\n" << b << "\n" << c << "\n" << d << endl;	// "Phone Book" 1. Add 2. Remove 3. Print
		} // when input enter

		else if (selectMenu == "1") {	// 1. Add
			cout << e << "\n" << f << "\n" << g << "\n" << h << "\n" << i << endl;	// "Select Type" 1. Person 2. Work 3. Family 4. Friend
			cout << "CP-2016-17466> ";

			int selectPersonType;
			cin >> selectPersonType;
			cin.get();

			switch (selectPersonType) {
				case 1:	// 1. Person
				{
					string firstName1, lastName1, phoneNumber1;

					cout << "Name: ";
					cin >> firstName1 >> lastName1;
					regex checkName("^[a-zA-Z]*$");
					while (!regex_match(firstName1, checkName) || !regex_match(lastName1, checkName)) {
						cout << "Name: ";
						cin >> firstName1 >> lastName1;
					}

					cout << "Phone_Number: ";
					cin >> phoneNumber1;
					regex checkFormat("(010|02)-(\\d{4})-(\\d{4})");
					while (!regex_match(phoneNumber1, checkFormat))
					{
						cout << "Phone_Number: ";
						cin >> phoneNumber1;
					}
					cin.get();

					Person* person = new Person(firstName1, lastName1, phoneNumber1);
					phoneBook.emplace_back(person);
					break;
				}
				case 2:	// 2. Work
				{
					string firstName2, lastName2, phoneNumber2, team;

					cout << "Name: ";							
					cin >> firstName2 >> lastName2;
					regex checkName("^[a-zA-Z]*$");
					while (!regex_match(firstName2, checkName) || !regex_match(lastName2, checkName)) {
						cout << "Name: ";
						cin >> firstName2 >> lastName2;
					}

					cout << "Phone_Number: ";
					cin >> phoneNumber2;
					regex checkFormat("(010|02)-(\\d{4})-(\\d{4})");
					while (!regex_match(phoneNumber2, checkFormat))
					{
						cout << "Phone_Number: ";
						cin >> phoneNumber2;
					}
					
					cout << "Team: ";
					cin >> team;
							
					Work* work = new Work(firstName2, lastName2, phoneNumber2, team);
					work->setTeam(team);
					cin.get();
					phoneBook.emplace_back(work);
					break;
				}
				case 3:	// 3. Family
				{
					string firstName3, lastName3, phoneNumber3, birthday;

					cout << "Name: ";								
					cin >> firstName3 >> lastName3;
					regex checkName("^[a-zA-Z]*$");
					while (!regex_match(firstName3, checkName) || !regex_match(lastName3, checkName)) {
						cout << "Name: ";
						cin >> firstName3 >> lastName3;
					}

					cout << "Phone_Number: ";
					cin >> phoneNumber3;
					regex checkFormat("(010|02)-(\\d{4})-(\\d{4})");
					while (!regex_match(phoneNumber3, checkFormat))
					{
						cout << "Phone_Number: ";
						cin >> phoneNumber3;
					}

					cout << "Birthday: ";
					cin >> birthday;
					regex checkFormat1 ("(\\d{2})(01|03|05|07|08|10|12)(0[1-9]|1[0-9]|2[0-9]|3[0-1])"); // Jan/Mar/May/Jul/Aug/Oct/Dec: 31 Days
					regex checkFormat2 ("(\\d{2})(04|06|09|11)(0[1-9]|1[0-9]|2[0-9]|30)"); // Apr/Jun/Sep/Nov: 30 Days
					regex checkFormat3 ("(\\d{2})(02)(0[1-9]|1[0-9]|2[0-8])"); // Feb: 28 Days (total 365 days in a year)
					while (!regex_match(birthday, checkFormat1)	&& !regex_match(birthday, checkFormat2)	&& !regex_match(birthday, checkFormat3))
					{
						cout << "Birthday: ";
						cin >> birthday;
					}

					Family* family = new Family(firstName3, lastName3, phoneNumber3, birthday);
					family->setBirthday(birthday);
					cin.get();
					phoneBook.emplace_back(family);
					break;
				}
				case 4:	// 4. Friend
				{
					string firstName4, lastName4, phoneNumber4;
					int age;

					cout << "Name: ";								
					cin >> firstName4 >> lastName4;
					regex checkName("^[a-zA-Z]*$");
					while (!regex_match(firstName4, checkName) || !regex_match(lastName4, checkName)) {
						cout << "Name: ";
						cin >> firstName4 >> lastName4;
					}

					cout << "Phone_Number: ";
					cin >> phoneNumber4;
					regex checkFormat("(010|02)-(\\d{4})-(\\d{4})");
					while (!regex_match(phoneNumber4, checkFormat))
					{
						cout << "Phone_Number: ";
						cin >> phoneNumber4;
					}

					cout << "Age: ";
					cin >> age;
					while (age <= 0) {
						cout << "Age: ";
						cin >> age;
					}

					Friend* myfriend = new Friend(firstName4, lastName4, phoneNumber4, age);
					myfriend->setAge(age);
					cin.get();
					phoneBook.emplace_back(myfriend);
					break;
				}
				default:
				{
					continue;
				}
			} // end of switch()
			cout << "Successfully added new person." << endl;
		} // end of '1. Add'

		else if (selectMenu == "2") { // 2. Remove
			cout << "Enter index of person: ";

			int removePerson;
			int phoneBookSizePlusOne = phoneBook.size() + 1;

			cin >> removePerson;
			cin.get();
			if (removePerson < phoneBookSizePlusOne) {
				phoneBook.erase(phoneBook.begin() + removePerson - 1); // entered index = 1 --> remove original index 0, since original 0 = printed 1
				cout << "A person is successfully deleted from the Phone Book!" << endl;
			}
			else {
				cout << "Person does not exist!" << endl;
				continue;
			}
		}

		else if (selectMenu == "3") { // 3. Print
			int phoneBookSize = phoneBook.size();
			for (int i = 0; i < phoneBookSize; i++)
			{
				cout << (i+1) << ". ";
				phoneBook[i]->print();
			}
		}

		else {
			continue;
		}

	} // end of while()
}; // end of main()